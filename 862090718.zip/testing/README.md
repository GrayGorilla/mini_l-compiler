# Mini_L-Compiler
Mini_L is a new coding language defined by this Compiler.

**Working Features**
    
    - Declarations
    - Math operations
    - Complete expressions
    - Math precedence
    - Arrays
    - Nested arrays
    - If/Else Conditionals
    - Complete boolean expressions (AND, OR, NESTED PAREN, NOT, ETC.)
    - While loops
    - Do while loops
    - For loops
    - Read
    - Write
    - Var lists of any kind
    - Return
    - Everything not listed in Incomplete Features

**Incomplete Features**

    - Function calls
    - Continue
